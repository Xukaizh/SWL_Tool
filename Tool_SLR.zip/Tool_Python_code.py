import torch
import joblib
import gpytorch
import pandas as pd
import numpy as np
import sys
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import os

# Get the directory where the script is located
base_dir = os.path.dirname(os.path.realpath(__file__))

# Define file paths relative to the base directory
data_file = os.path.join(base_dir, 'Data19952005_3h.csv')
model_file = os.path.join(base_dir, 'gp_model.pth')
scaler_file = os.path.join(base_dir, 'scaler.pkl')
input_data_file = os.path.join(base_dir, 'input_data.csv')
future_trend_file = os.path.join(base_dir, 'Future water level USACE.xlsx')
output_file = os.path.join(base_dir, 'output_data.csv')
swl_plot_file = os.path.join(base_dir, 'SWL.png')
pof_all_plot_file = os.path.join(base_dir, 'PoF_all.png')
pof_monthly_mean_plot_file = os.path.join(base_dir, 'PoF_monthly_mean.png')

class SinusoidalMean(gpytorch.means.Mean):
    def __init__(self, amplitude=2.0, frequency=0.1, phase=0.0):
        super().__init__()
        self.amplitude = torch.nn.Parameter(torch.tensor(amplitude))
        self.frequency = torch.nn.Parameter(torch.tensor(frequency))
        self.phase = torch.nn.Parameter(torch.tensor(phase))

    def forward(self, x):
        sinusoidal = self.amplitude * torch.sin(self.frequency * x + self.phase)
        return sinusoidal.mean(dim=-1)

class GPModel(gpytorch.models.ExactGP):
    def __init__(self, train_x, train_y, likelihood, amplitude=1.0, frequency=1.0, phase=0.0):
        super(GPModel, self).__init__(train_x, train_y, likelihood)
        self.mean_module = SinusoidalMean(amplitude=amplitude, frequency=frequency, phase=phase)
        self.covar_module = gpytorch.kernels.ScaleKernel(gpytorch.kernels.RBFKernel(eps=1e-05))

    def forward(self, x):
        mean_x = self.mean_module(x)
        covar_x = self.covar_module(x)
        return gpytorch.distributions.MultivariateNormal(mean_x, covar_x)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
df = pd.read_csv(data_file, parse_dates=['Time'])

df9599 = df[(df['Time'].dt.year >= 1995) & (df['Time'].dt.year <= 1999)]
X = df9599[['Month', 'Day', 'Hour', 'sea_surface_wave_significant_height','sea_surface_wave_mean_period', 'wind_speed', 'WSPD']]
X = pd.get_dummies(X, columns=['Month'])
y = df9599['SLR(NoTideVar)']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=452)

train_indexes = X_train.index
test_indexes = X_test.index

test_times = df9599.loc[test_indexes, 'Time']
train_times = df9599.loc[train_indexes, 'Time']

test_times_np = test_times.to_numpy()
train_times_np = train_times.to_numpy()

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

train_x = torch.tensor(X_train_scaled).float().to(device)
train_y = torch.tensor(y_train.values).float().to(device).squeeze(-1)

#######################################################################################################Define train_x,y before , if not, GPModel gives different result.

model = GPModel(train_x, train_y, gpytorch.likelihoods.GaussianLikelihood(), amplitude=5.0, frequency=8.0, phase=0.0).to(device)
likelihood = gpytorch.likelihoods.GaussianLikelihood().to(device)
model.load_state_dict(torch.load(model_file))
model.eval()

all_months = [f'Month_{i}' for i in range(1, 13)]

df_new = pd.read_csv(input_data_file)

df_new['Time'] = pd.to_datetime(df_new['Time'], format='%m/%d/%Y %H:%M')

df_new['Hour'] = df_new['Time'].dt.hour
df_new['Day'] = df_new['Time'].dt.day
df_new['Month'] = df_new['Time'].dt.month
df_new['Year'] = df_new['Time'].dt.year

X_new = df_new[[ 'Month', 'Day', 'Hour', 'sea_surface_wave_significant_height', 'sea_surface_wave_mean_period', 'wind_speed', 'WSPD']]
X_new = pd.get_dummies(X_new, columns=['Month'])

X_new = X_new.reindex( columns=
                             ['Day', 'Hour', 'sea_surface_wave_significant_height', 
                              'sea_surface_wave_mean_period', 'wind_speed', 'WSPD'] +all_months, 
                      fill_value=0)

scaler = joblib.load(scaler_file)
X_new_scaled = scaler.transform(X_new)

X_new_tensor = torch.tensor(X_new_scaled).float().to(device)

# Make predictions
with torch.no_grad(), gpytorch.settings.fast_pred_var():
    observed_pred = likelihood(model(X_new_tensor))
    mean_pred = observed_pred.mean.cpu().numpy()
    lower, upper = observed_pred.confidence_region()
    lower = lower.cpu().numpy()
    upper = upper.cpu().numpy()
    predictions_variance = observed_pred.variance.cpu().numpy()

# Save the predictions
df_new_predictions = pd.DataFrame({
    'Time': df_new['Time'],
    'Year': df_new['Year'],
    'Predicted_Mean': mean_pred,
    'Predictive Variance': predictions_variance,
    'Lower_Bound': lower,
    'Upper_Bound': upper
})

df_new_predictions = df_new_predictions.merge(df_new[['Time', 'Tide']], on='Time', how='left')

###################MSL
df_trend_future = pd.read_excel(future_trend_file)

df_new_predictions = pd.merge(df_new_predictions, df_trend_future[['Year','USACE_low','USACE_int','USACE_high']], on='Year', how='left')

# Drop the 'Year' column from df_new_predictions
df_new_predictions = df_new_predictions.drop(columns=['Year'])
##################Finish import MSL

###################Different combinations####################
df_new_predictions['SWL_LOW'] = df_new_predictions['Tide'] + df_new_predictions['USACE_low']
df_new_predictions['SWL_INT'] = df_new_predictions['Tide'] + df_new_predictions['USACE_int']
df_new_predictions['SWL_HIGH'] = df_new_predictions['Tide'] + df_new_predictions['USACE_high']

###########################
# Adjusted to pair mean with the square root of variance (to get the standard deviation)
Hm0_distributions = [(mean, np.sqrt(variance)) for mean, variance in zip(df_new_predictions['Predicted_Mean'], df_new_predictions['Predictive Variance'])]

def estimate_pof(Hm0_dist_params, Rc, q_lim, n_simulations=10000):
    g = 9.81
    Hm0 = np.abs(np.random.normal(Hm0_dist_params[0], Hm0_dist_params[1], n_simulations))
    q = np.sqrt(g * Hm0**3) * 0.054 * np.exp(-(2.12 * (Rc / Hm0))**1.3)
    return np.sum(q >= q_lim) / n_simulations

#deterioration rate
deteriorate_subsidence = 3.51 #mm/a
deteriorate_settlement = 4.00 #mm/a
deterioration_rate = deteriorate_subsidence + deteriorate_settlement
deterioration_rate_per_hour = deterioration_rate / 8760  # mm/hour
deterioration_per_3_hours = deterioration_rate_per_hour * 3  # mm/3 hours
deterioration_per_3_hours_m = deterioration_per_3_hours / 1000  # Convert mm to meters

# Assuming baseline Rc and q_lim
baseline_Rc = 4.2672 + 0.31/3.281 -0.83/3.281  # Base value in meters    
#Using Datums for 8771450, Galveston Pier 21 TX
#Based on the 2024 Sea water level data on Galveston seawall ######### 1 m = 3.281 ft
#2024 MLLW is -0.31 to the NAVD 88.
#The height of the seawall is 4.8672 m. The foot of the seawall is -0.6m to 0m to NAVD 88, which is assumed to be -0.6m. The height of the seawall removing foot is 4.2672 m, because the foot is not included to calculate the wave overtopping. 
#Because the MLLW, so Rc is 4.2672+0.31/3.281 
#0.83 ft, transfer the data to Mean Sea Level based on data from: https://tidesandcurrents.noaa.gov/datums.html?datum=MLLW&units=0&epoch=0&id=8771450&name=Galveston+Pier+21&state=TX

######Overtopping discharge limit
# Default value for overtopping discharge limit
default_value = 0.01

# Check if an argument is provided
if len(sys.argv) > 1:
    try:
        cell_value = float(sys.argv[1])  # Try to convert to float
    except ValueError:
        cell_value = default_value
else:
    cell_value = default_value

print(f"The value from Excel cell A1 is: {cell_value}")

q_lim = cell_value # Value from excel
##############################################
# Initialize a time step counter
time_step = 0

# Calculate PoF for each scenario
def calculate_pof_row(row, baseline_Rc, q_lim, time_step):
    Hm0_dist_params = (row['Predicted_Mean'], np.sqrt(row['Predictive Variance']))
    
    # Calculate Rc deterioration for the current time step
    Rc_deterioration = deterioration_per_3_hours_m * time_step

    # Adjust Rc for each scenario
    Rc_low = (baseline_Rc - Rc_deterioration) - row['SWL_LOW']
    Rc_int = (baseline_Rc - Rc_deterioration) - row['SWL_INT']
    Rc_high = (baseline_Rc - Rc_deterioration) - row['SWL_HIGH']

    # Calculate PoF for each scenario
    pof_low = estimate_pof(Hm0_dist_params, Rc_low, q_lim)
    pof_int = estimate_pof(Hm0_dist_params, Rc_int, q_lim)
    pof_high = estimate_pof(Hm0_dist_params, Rc_high, q_lim)
    
    return pd.Series([pof_low, pof_int, pof_high])

# Convert SWL to NAVD 88 (MLLW adjustment)
mlLW_adjustment = -0.31 / 3.281
df_new_predictions['SWL_LOW'] += mlLW_adjustment
df_new_predictions['SWL_INT'] += mlLW_adjustment
df_new_predictions['SWL_HIGH'] += mlLW_adjustment

# Apply the PoF calculation for each row, including deterioration over time
pof_columns = df_new_predictions.apply(
    lambda row: calculate_pof_row(row, baseline_Rc, q_lim, time_step), axis=1
)

# Assign new PoF columns to the DataFrame
df_new_predictions[['PoF_LOW', 'PoF_INT', 'PoF_HIGH']] = pof_columns

# Save the results
df_new_predictions.to_csv(output_file, index=False)
print("df_new_predictions", df_new_predictions)

#################Plot##########################

###############Plot for SWL####################
# Plotting
plt.figure(figsize=(5, 3))  # Set the figure size (optional)
plt.plot(df_new_predictions['Time'], df_new_predictions['SWL_HIGH'], label='SWL_HIGH', linewidth=1, color = 'red')
plt.plot(df_new_predictions['Time'], df_new_predictions['SWL_INT'], label='SWL_INT', linewidth=1, color = 'orange')
plt.plot(df_new_predictions['Time'], df_new_predictions['SWL_LOW'], label='SWL_LOW', linewidth=1,color = 'gray')

# Set background color of the axes
ax = plt.gca()  # Get current axes
ax.set_facecolor('#F0F0F0')  # Set the background color
ax.grid(color='white', linestyle='solid', linewidth=0.8)  # You might also want to change the grid color to white
# Set the x-axis to show a maximum of 4 labels
from matplotlib.ticker import MaxNLocator
ax.xaxis.set_major_locator(MaxNLocator(nbins=5))

# Rotate date labels on x-axis
plt.xticks(rotation=35)
#plt.title('Predicted Sea Water Level Over Time')  # Add a title to the plot
plt.xlabel('Time')  # Add an x-label
plt.ylabel('Sea Water Level')  # Add a y-label
plt.legend()  # Add a legend
plt.tight_layout()  # Adjust the layout to not cut off anything
plt.savefig(swl_plot_file)

#################Plot for PoF##################
#1.Plot for all################################

# Plotting
plt.figure(figsize=(5, 3))  # Set the figure size (optional)
plt.plot(df_new_predictions['Time'], df_new_predictions['PoF_HIGH'], label='PoF_HIGH', linewidth=1, color = 'red')
plt.plot(df_new_predictions['Time'], df_new_predictions['PoF_INT'], label='PoF_INT', linewidth=1, color = 'orange')
plt.plot(df_new_predictions['Time'], df_new_predictions['PoF_LOW'], label='PoF_LOW', linewidth=1,color = 'gray')

# Set background color of the axes
ax = plt.gca()  # Get current axes
ax.set_facecolor('#F0F0F0')  # Set the background color
ax.grid(color='white', linestyle='solid', linewidth=0.8)  # You might also want to change the grid color to white
ax.xaxis.set_major_locator(MaxNLocator(nbins=5))
# Rotate date labels on x-axis
plt.xticks(rotation=35)
#plt.title('Probability of Failure on Wave Overtopping Over Time')  # Add a title to the plot
plt.xlabel('Time')  # Add an x-label
plt.ylabel('Probability of Failure')  # Add a y-label
plt.legend()  # Add a legend
plt.tight_layout()  # Adjust the layout to not cut off anything
plt.savefig(pof_all_plot_file)

#2.Monthly average#############################
# Resample to get monthly data
df_new_predictions['Time'] = pd.to_datetime(df_new_predictions['Time'])
monthly_max = df_new_predictions.resample('M', on='Time').max()
monthly_mean = df_new_predictions.resample('M', on='Time').mean()
# Plotting the Mean values
plt.figure(figsize=(5, 3))
plt.plot(monthly_mean.index, monthly_mean['PoF_HIGH'], label='PoF_HIGH', color='#D93E02')
plt.plot(monthly_mean.index, monthly_mean['PoF_INT'], label='PoF_INT', color='#021BD9')
plt.plot(monthly_mean.index, monthly_mean['PoF_LOW'], label='PoF_LOW', color='#54D902')

# Set background color of the axes
ax = plt.gca()  # Get current axes
ax.set_facecolor('#F0F0F0')  # Set the background color
ax.grid(color='white', linestyle='solid', linewidth=0.8)  # You might also want to change the grid color to white
ax.xaxis.set_major_locator(MaxNLocator(nbins=5))
# Rotate date labels on x-axis
plt.xticks(rotation=35)

#plt.title('Mean Probability of Failure per Month (2026 - 2037)')
plt.xlabel('Time', fontsize=12)
plt.ylabel('Probability of Failure', fontsize=12)
plt.legend()
plt.tight_layout()
plt.savefig(pof_monthly_mean_plot_file)
